import sys, re, wx, time, wx.grid, argparse, numpy as np, \
	networkx as netx, matplotlib.pyplot as plt
from AntColonyOptimizer import AntColonyOptimizer as aco
from AcoSearch import AcoSearchM, AcoSearchS, \
	AcoPsoSearch, AcoPsoSearchEx, AcoPsoSearchEy
from scipy.spatial import distance
from multiprocessing import Process
from numpy import transpose as trans

def RandGraph(nx=6,ny=5,density=0.3,show=False,outPath=None):
	#--- random data points
	#p = np.random.rand(nx*ny,2) * 10
	#--- random data points on grid template
	a,b = np.meshgrid(np.arange(nx),np.arange(ny))
	c,d = -1 + 2*np.random.rand(2,ny,nx)
	p = np.append((5*a+c).reshape(nx*ny,1),(5*b+d).reshape(nx*ny,1),axis=1)
	#--- distance matrix
	x = distance.cdist(p,p)
	#--- remove so-far distanced links
	idx = np.argsort(x,axis=1)
	I = np.transpose([np.arange(len(p))])
	J = idx[:,int(density*len(p)):]
	x[I,J] = x[J,I] = 0

	#--- remove edges that are very close to another nodes
	R = np.min(x[x>0]) / 2
	idx = np.transpose(np.where(np.triu(x) > 0))
	#--- get start/end node of edges
	xi = np.repeat(trans([p[idx[:,0],0]]),p.shape[0],axis=1)
	yi = np.repeat(trans([p[idx[:,0],1]]),p.shape[0],axis=1)
	xj = np.repeat(trans([p[idx[:,1],0]]),p.shape[0],axis=1)
	yj = np.repeat(trans([p[idx[:,1],1]]),p.shape[0],axis=1)
	#--- line segment paramerts : ax + by + c = 0
	a = (yj-yi); b = (xj-xi); c = yi*b - xi*a
	#--- nodes coordinates
	u = np.repeat([p[:,0]],a.shape[0],axis=0)
	v = np.repeat([p[:,1]],b.shape[0],axis=0)
	#--- calc distance of each node to edges
	d = np.abs(a*u-b*v+c) / np.sqrt(a**2 + b**2)
	#--- calc length of projection vectors
	h1 = np.sqrt((xi-u)**2 + (yi-v)**2 - d**2)
	h2 = np.sqrt((xj-u)**2 + (yj-v)**2 - d**2)
	#--- calc length of edge : both projection vectors must be less than this
	hh = np.sqrt((xi-xj)**2 + (yi-yj)**2)
	#--- indices of start node of edges
	I = np.repeat(trans([idx[:,0]]),p.shape[0],axis=1)
	#--- indices of end node of edges
	J = np.repeat(trans([idx[:,1]]),p.shape[0],axis=1)
	#--- indices of nodes
	K = np.repeat([np.arange(p.shape[0])],idx.shape[0],axis=0)
	#--- check all pairs of edges/nodes for if : start and end 
	#---  node of edge isn't equal to tobe check node and distance 
	#---  is less than a threshold and also check projection length
	jdx = (I != K) & (J != K) & (d <= R) & (h1 < hh) & (h2 < hh)
	#--- purify edge list
	idx = idx[np.sum(jdx,axis=1) > 0, :]
	#--- update distance matrix
	x[idx[:,0],idx[:,1]] = x[idx[:,1],idx[:,0]] = 0

	if show: Process(target=DrawGraph,args=(x,p)).start()

	if outPath is None:
		input_key = input('Save this map? Yes(y) / No(n): ')
		while input_key not in '[yYnN]':
			input_key = input('Save this map? Yes(y) / No(n): ')
		if input_key in 'yY': outPath = input('Enter file path : ')
	if outPath is not None:
		fmtE = 'edge-%03d\t%2d\t%2d\n'
		fmtV = 'vertice-%02d\t%6.4f\t%6.4f\n'
		#--- get non-zero elements of the distance matrix
		q = np.transpose(np.where(np.triu(x) > 0))
		#--- convert vertices and edges data to text lines
		txtList = list(fmtV % (k+1,p[k,0],p[k,1]) for k in range(len(p))) + \
			list(fmtE % (k+1,q[k,0],q[k,1]) for k in range(len(q)))
		#np.savetxt("Map.csv", distMap, fmt='%3.2f', delimiter=",")
		try:
			#--- open file as text stream
			f = open(outPath, 'w')
			#--- write all vertice lines
			d = f.writelines(txtList)
			#--- close file handle
			f.close()
			print('Output file was saved successfully!')
		except Exception as ex:
			print(ex)

	return x,p

def ReadDataset(fPath,density=0.3,show=False):
	try:
		f = open(fPath, 'r')#--- open file as text stream
		D = f.readlines()	#--- read all lines
		f.close()			#--- close file handle
	except Exception as ex:
		print(ex)
		return None
	
	#--- find lines start with prefix "vertice-"
	idx = list(s.startswith('vertice-') for s in D)
	#--- find lines start with prifix "edge-"
	jdx = list(s.startswith('edge-') for s in D)
	#--- separate numerical data lines by space delimiter
	x = np.array(list(np.array(s[8:].split()) for s in D),dtype='object')[idx]
	#--- convert separated strings to float values
	p = np.float32(list(t for t in x))[:,1:]
	#--- distance matrix
	M = distance.cdist(p,p)
	x = M.copy()
	g = np.zeros(x.shape,'bool')
	if np.sum(jdx) == 0:
		#--- remove so-far distanced links
		k = int(density*x.shape[1])
		idx = np.argsort(x,axis=1)[:,k:]
		#--- remove randomly some pathes
		g[np.transpose([np.arange(len(p))]),idx] = True
	else:
		#--- separate numerical data lines by space delimiter
		V = np.array(list(np.array(s[4:].split()) for s in D),dtype='object')[jdx]
		#--- convert separated strings to float values
		jdx = np.int32(list(t for t in V))[:,1:]
		g[jdx[:,0],jdx[:,1]] = True
	g |= g.transpose()
	x[~g] = 0
	
	if show:
		#plt.scatter(x[:,0],x[:,1]); plt.show();plt.pause(0)
		np.set_printoptions(precision=2,threshold=3)
		y = x * np.triu(np.ones(x.shape))
		idx = np.transpose(np.where(y > 0))
		#--- list of vertices
		verts = list((v,{"color":"blue"}) for v in range(x.shape[0]))
		#--- list of edges
		edges = list((e[0],e[1],{'weight': '%3.2f'%x[e[0],e[1]]}) for e in idx)
		#--- geometerical position of vertices
		pos = dict((k,tuple(p[k,:])) for k in range(len(p)))
		options = {'pos':pos,'node_color': 'gray',\
			'node_size': 500,'width': 1,'with_labels':True}
		G = netx.Graph()
		G.add_nodes_from(verts)
		G.add_edges_from(edges)
		lbl = netx.get_edge_attributes(G,'weight')
		plt.figure('map')
		plt.subplot(111)
		netx.draw(G,**options)
		netx.draw_networkx_edge_labels(G,pos,edge_labels=lbl,font_size=8)
		plt.show()
	M[~g] = 0
	return M,p

def DrawGraph(x,p):
	plt.figure('Urban Stations Map')

	idx = np.transpose(np.where(np.triu(x) > 0))
	#--- list of vertices
	verts = list((v,{"color":"blue"}) for v in range(x.shape[0]))
	#--- list of edges
	edges = list((i,j,{'color':'#FF0044', 'weight': '%3.2f' % x[i,j]}) for i,j in idx)
	#--- geometerical position of vertices
	pos = dict((k,tuple(p[k,:])) for k in range(len(p)))

	options = {'pos':pos,'node_color': '#8888CC','font_size':10,\
		'node_size': 500,'width': 1,'edge_color': '#CC8888','with_labels':True}
	G = netx.Graph()
	G.add_nodes_from(verts)
	G.add_edges_from(edges)
	lbl = netx.get_edge_attributes(G,'weight')
	netx.draw(G,**options)
	netx.draw_networkx_edge_labels(G,pos,edge_labels=lbl,font_size=8)
	plt.plot();plt.show()

def PathPlanning(Map, points, x0=None, startNode=0, \
				destNode=-1, numAnts=20, iters=1000):
	#--- number of map intersections: vertices_count
	STATIONS_COUNT = Map.shape[0]
	#--- number of map roads: edges_count // 2
	ROADS_COUNT = np.sum(Map > 0) // 2

	destNode %= STATIONS_COUNT
	startNode %= STATIONS_COUNT
	if startNode == destNode: destNode = (startNode + 1) % STATIONS_COUNT
	acOptimizer = aco(numAnts=numAnts, evapRate=0.1, intensRate=0.25, \
		alpha=1, beta=1, evapRateB=0, choose_best=0.1)
	_,best_path = acOptimizer.fit(Map, points, x0, start=startNode, \
			dest=destNode, iterations=iters, maxStuck=20)
	print(best_path)

if __name__ == '__main__':
	#RandGraph(9,8,0.1,True);sys.exit(0)
	bVectorized = False; x0 = None
	parser = argparse.ArgumentParser(description="ACO-PSO Civil Path Planning")
	parser.add_argument("--db", default='sample25.tsp', help="Database filename")
	parser.add_argument("--x0", type=str, default=None, help="Initial solution")
	parser.add_argument("--ants", type=int, default=20, help="Ants count")
	parser.add_argument("--iters", type=int, default=100, help="Iterations")
	parser.add_argument("--start", type=int, default=0, help="Start point")
	parser.add_argument("--dest", type=int, default=-1, help="Destination point")
	parser.add_argument("--c1", type=float, default=0.95, help="PSO param C1")
	parser.add_argument("--c2", type=float, default=0.05, help="PSO param C2")
	parser.add_argument("--stuck", type=int, default=20, help="Maximum count of no-improvement")
	parser.add_argument("-vect", action="store_true", help="if TRUE, perform vectorized ACO")
	#--- intialize parameters based on user input
	args = parser.parse_args()
	if args.x0 is not None:
		regex = '^\s*[\[\(\{]?[,\s]*([-+]?\d+\.?\d*)+' + \
			'([\s*,]+([-+]?\d+\.?\d*)+)*[,\s]*[\]\)\}]?\s*$'
		if re.match(regex, args.x0):
			nums = re.findall(r'[-+]?\d+\.?\d*',args.x0)
			x0 = np.abs(list(int(float(t)) for t in nums))
		else:
			print('Invalid value for initial solution!\n' + \
				'Just a list of positive integers is allowed.')
	if args.db is not None: dbFName = args.db
	if args.iters is not None: itersCount = args.iters
	if args.start is not None: startNode = args.start
	if args.ants is not None: antsCount = args.ants
	if args.dest is not None: destNode = args.dest
	if args.stuck is not None: maxStuck = args.stuck
	if args.c1 is not None: c1 = args.c1
	if args.c2 is not None: c2 = args.c2
	if args.vect: bVectorized = True

	distMap,pointsList = ReadDataset(fPath=dbFName,density=0.2)
	#distMap,pointsList = RandGraph(6,8,0.15,show=True,outPath='sample48.tsp')
	if distMap is not None and len(distMap) > 0:
		if bVectorized:
			#AcoPsoSearch(distMap,pointsList,x0,startNode,destNode,\
			#	antsCount,itersCount,c1=c1,c2=c2,maxStuck=maxStuck)
			
			#--- random matrix as roads congestion
			CongestMap = np.float32(distMap > 0) * 100
			AcoPsoSearchEy(distMap,CongestMap,pointsList,x0,startNode,\
				destNode,antsCount,itersCount,c1=c1,c2=c2,maxStuck=maxStuck)
		else:
			PathPlanning(distMap,pointsList,x0,startNode,destNode,\
				antsCount,itersCount,maxStuck=maxStuck)
	else:
		print('---> ERROR : Could not read/create database file!')