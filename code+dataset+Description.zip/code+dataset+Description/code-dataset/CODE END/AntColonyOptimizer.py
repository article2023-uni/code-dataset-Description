import sys, time, warnings, networkx as netx, \
	numpy as np, matplotlib.pyplot as plt
from numpy import transpose as trans
from multiprocessing import Process

warnings.filterwarnings("ignore")

class AntColonyOptimizer():
	'''
	---------------------------------
	Ant Colony Optimization Algorithm
	---------------------------------
	Usage Example:
	>>> problem = some_distance_matrix
	>>> optimizer = AntColonyOptimizer(ants=10, 
	>>> 	evaporation_rate=0.1, intensification=2, alpha=1, 
	>>> 	beta=1, beta_evaporation_rate=0, choose_best=0.1)
	>>> best = optimizer.fit(problem, 100)
	>>> optimizer.plot()
	'''
	
	def __init__(self, numAnts=10, evapRate=0.5, intensRate=0.5, 
			alpha=1.0, beta=0.01, evapRateB=0, choose_best=0.1):
		"""
		Ant colony optimizer.  Traverses a graph and finds either the max or min distance between nodes.
		:param numAnts: number of ants to traverse the graph
		:param evaporation_rate: rate at which pheromone evaporates
		:param intensification: constant added to the best path
		:param alpha: weighting of pheromone
		:param beta: weighting of heuristic (1/distance)
		:param beta_evaporation_rate: rate at which beta decays (optional)
		:param choose_best: probability to choose the best route
		"""
		# Parameters
		self.antsCount = numAnts
		#--- pheromone evaporation rate
		self.evapRate = evapRate
		#--- pheromone intensification rate
		self.intensRate = intensRate
		#--- alpha heuristic rate
		self.heuristic_alpha = alpha
		#--- betha heuristic rate
		self.heuristic_beta = beta
		#--- betha evaporation rate
		self.evapRateBetha = evapRateB
		#--- best choice probability ignoring others
		self.choose_best = choose_best

		# Internal representations
		self.MatrixPheromone = None
		self.MatrixHeuristic = None
		self.MatrixProbability = None

		#--- data points coordinates
		self.points = None
		#--- distance matrix
		self.MatrixMap = None
		#--- list of nodes currently can be choosed
		self.availableNodes = None

		# Internal stats
		self.best_series = []
		self.best = None
		self.fitted = False
		self.best_path = None
		self.fit_time = None

		# Plotting values
		self.stopped_early = False

		# Graph values
		self.graph = None
		self.graphOptions = {'node_color': '#8888CC','font_size':10,\
					'node_size': 300,'width': 1,'with_labels':True}

	def __str__(self):
		string = "Ant Colony Optimizer"
		string += "\n--------------------"
		string += "\nDesigned to optimize either the minimum or maximum distance between nodes in a square matrix that behaves like a distance matrix."
		string += "\n--------------------"
		string += "\nNumber of ants:\t\t\t\t{}".format(self.antsCount)
		string += "\nEvaporation rate:\t\t\t{}".format(self.evapRate)
		string += "\nIntensification factor:\t\t{}".format(self.intensRate)
		string += "\nAlpha Heuristic:\t\t\t{}".format(self.heuristic_alpha)
		string += "\nBeta Heuristic:\t\t\t\t{}".format(self.heuristic_beta)
		string += "\nBeta Evaporation Rate:\t\t{}".format(self.evapRateBetha)
		string += "\nChoose Best Percentage:\t\t{}".format(self.choose_best)
		string += "\n--------------------"
		string += "\nUSAGE:"
		string += "\nNumber of ants influences how many paths are explored each iteration."
		string += "\nThe alpha and beta heuristics affect how much influence the pheromones or the distance heuristic weigh an ants' decisions."
		string += "\nBeta evaporation reduces the influence of the heuristic over time."
		string += "\nChoose best is a percentage of how often an ant will choose the best route over probabilistically choosing a route based on pheromones."
		string += "\n--------------------"
		if self.fitted:
			string += "\n\nThis optimizer has been fitted."
		else:
			string += "\n\nThis optimizer has NOT been fitted."
		return string

	def _initialize(self):
		"""
		Initializes the model by creating the various matrices 
			and generating the list of available nodes
		"""
		assert self.MatrixMap.shape[0] == self.MatrixMap.shape[1], "Map is not a distance matrix!"
		num_nodes = self.MatrixMap.shape[0]
		self.MatrixPheromone = 1 - np.eye(num_nodes)
		#self.MatrixPheromone = np.ones((num_nodes, num_nodes))
		##-- Remove the diagonal since there is no pheromone from node i to itself
		#self.MatrixPheromone[np.eye(num_nodes) == 1] = 0
		self.MatrixHeuristic = 1 / self.MatrixMap
		self.MatrixHeuristic[self.MatrixMap == 0] = 0
		self.MatrixProbability = (self.MatrixPheromone ** self.heuristic_alpha) * (
				self.MatrixHeuristic ** self.heuristic_beta)  # element by element multiplcation
		self.availableNodes = list(range(num_nodes))
		idx = np.isnan(self.MatrixProbability) | np.isinf(self.MatrixProbability)
		self.MatrixProbability[idx] = 0

	def _reinstate_nodes(self):
		"""
		Resets available nodes to all nodes for the next iteration
		"""
		self.availableNodes = list(range(self.MatrixMap.shape[0]))

	def _update_probabilities(self):
		"""
		After evaporation and intensification, the probability matrix needs to be updated.  This function
		does that.
		"""
		self.MatrixProbability = (self.MatrixPheromone ** self.heuristic_alpha) * (
				self.MatrixHeuristic ** self.heuristic_beta)
		idx = np.isnan(self.MatrixProbability) | np.isinf(self.MatrixProbability)
		self.MatrixProbability[idx] = 0

	def _choose_next_node(self, from_node, available_nodes):
		"""
		Chooses the next node based on probabilities.  
		If p < p_choose_best, then the best path is chosen, otherwise
		it is selected from a probability distribution weighted by the pheromone.
		:param from_node: the node the ant is coming from
		:return: index of the node the ant is going to
		"""
		numerator = self.MatrixProbability[from_node, available_nodes]
		denominator = np.sum(numerator)
		#--- if there is no choice, return -1; means the path is banned
		if denominator == 0: return -1
		if np.random.random() < self.choose_best:
			next_node = np.argmax(numerator)
		else:
			probabilities = numerator / denominator
			next_node = np.random.choice(range(len(probabilities)), p=probabilities)
		return next_node

	def _remove_node(self, node):
		self.availableNodes.remove(node)

	def _evaluate(self, paths, mode='min'):
		"""
		Evaluates the solutions of the ants by 
		  adding up the distances between nodes.
		:param paths: solutions from the ants
		:param mode: string value of {'max' , 'min'}
		:return: x and y coordinates of the best path as a 
				 tuple, the best path, and the best score
		"""
		if mode not in ['min','max']:
			raise ValueError("Invalid mode!  Choose 'min' or 'max'.")

		scores = np.array(list(np.sum(self.MatrixMap[\
			path[:-1],path[1:]]) for path in paths))
		idx = np.argsort(scores)
		if mode == 'max': idx = idx[::-1]
		return idx, scores

	def _evaluate2(self, paths, mode='min'):
		"""
		Evaluates the solutions of the ants by 
		  adding up the distances between nodes.
		:param paths: solutions from the ants
		:param mode: string value of {'max' , 'min'}
		:return: x and y coordinates of the best path as a 
				 tuple, the best path, and the best score
		"""
		if mode not in ['min','max']: raise ValueError("Invalid mode!  Choose 'min' or 'max'.")

		x = np.array(paths)
		scores = np.sum(self.MatrixMap[x[:,:-1],x[:,1:]],axis=1)
		if mode == 'min': best = np.argmin(scores)
		else: best = np.argmax(scores)
		return (np.array(paths)[best,:-1], np.array(paths)[best,1:]), paths[best], scores[best]

	def _evaporation(self):
		"""
		Evaporate some pheromone as the inverse of the evaporation rate.  Also evaporates beta if desired.
		"""
		self.MatrixPheromone *= (1 - self.evapRate)
		self.heuristic_beta *= (1 - self.evapRateBetha)

	def _intensify(self, path):
		"""
		Increases the pheromone by some scalar for the best route.
		@param <best_coords>: x and y (i and j) coordinates of the best route
		"""
		#--- update pheromone amount for each road of the path
		i = path[:-1]; j = path[1:]
		self.MatrixPheromone[i,j] += self.intensRate
		self.MatrixPheromone[j,i] += self.intensRate
		
		#--- also update pheromone amount for each road of the best path
		i = self.best_path[:-1]; j = self.best_path[1:]
		self.MatrixPheromone[i,j] += self.intensRate
		self.MatrixPheromone[j,i] += self.intensRate

	def _intensifyVect(self, paths, scores, mode='min'):
		"""
		Increases the pheromone by some scalar for the best route.
		@param <best_coords>: x and y (i and j) coordinates of the best route
		"""
		if mode == 'min':
			#--- calculate path's weight by its score
			#--- add small value 1e-9 to prevent division-by-zero
			weights = 1 / (scores + 1e-9)
			weights = np.array(weights) / np.max(weights)
		else:
			weights = np.array(scores) / np.max(scores)
		# list(f for g in list(tuple(path[:-1]) for path in paths) for f in g)
		# list(f for g in list(tuple(path[+1:]) for path in paths) for f in g)
		for k in range(1):
			i = paths[k][:-1]; j = paths[k][1:]
			#--- update pheromone amount for each path based on its weight
			self.MatrixPheromone[i,j] += weights[k] * self.intensRate
			self.MatrixPheromone[j,i] += weights[k] * self.intensRate

	def _CheckInitialSolution(self, x0, startNode, destNode):
		return x0 is not None and \
			min(x0) >= 0 and max(x0) < self.MatrixMap.shape[0] and \
			x0[0] == startNode and x0[-1] == destNode and \
			np.prod(self.MatrixMap[x0[:-1],x0[1:]] > 0) > 0

	def fit(self, map_matrix, points_arr, x0=None, \
			start=None, dest=None, iterations=100, \
			mode='min', maxStuck=-1, stuckTolerance=1e-6, verbose=True):
		"""
		Fits the ACO to a specific distance map. 
		This was designed with the Traveling Salesman problem in mind.
		@param <map_matrix>: Distance matrix or some other matrix with similar properties
		@param <iterations>: number of iterations
		@param <mode>: whether to get the minimum path or maximum path
		@param <maxStuck>: how many iterations of the same score
									   to make the algorithm stop early
		@return: the best score
		"""

		if mode not in ['min','max']:
			raise ValueError("Invalid mode! Choose 'min' or 'max'.")

		patternTxt = "Beginning ACO Optimization with {} iterations..."
		if verbose: print(patternTxt.format(iterations))
		maxStuck %= iterations
		if mode == 'min': self.best = np.inf
		else: self.best = 0
		self.MatrixMap = map_matrix
		self.points = points_arr
		self.createGraph()
		lastTime = time.time()
		self._initialize()
		lastBest = np.inf
		no_change = 0
		plt.figure('Urban Stations Map');plt.ion()

		if dest is None: dest = self.Map.shape[0] - 1
		if start is None: start = 0

		if self._CheckInitialSolution(x0,start,dest):
			self.best_path = x0
			self._intensify(np.array(x0))
			self._update_probabilities()

		for i in range(iterations):
			start_iter = time.time()
			path = []; paths = []

			for ant in range(self.antsCount):
				available_nodes = np.arange(self.MatrixMap.shape[0])
				start_node = start; dest_node = dest
				#start_node = np.random.randint(0, self.MatrixMap.shape[0])
				current_node_idx = start_node
				current_node = start_node
				while True:
					path.append(current_node)
					available_nodes = np.delete(available_nodes,current_node_idx)
					if current_node == dest_node or len(available_nodes) == 0: break
					current_node_idx = self._choose_next_node(current_node,available_nodes)
					if current_node_idx < 0: break
					current_node = available_nodes[current_node_idx]

				#path.append(start_node)  # go back to start
				self._reinstate_nodes()
				if path[-1] == dest_node: paths.append(path)
				path = []

			if len(paths) == 0: continue
			#--- sort paths based on their length
			idx, scores = self._evaluate(paths, mode)
			best_path = np.array(paths)[idx]
			best_score = scores[idx]
			if mode == 'min':
				if self.best > best_score[0]:
					self.best_path = best_path[0]
					self.best = best_score[0]
			else:
				if self.best < best_score[0]:
					self.best_path = best_path[0]
					self.best = best_score[0]

			self.best_series.append(best_score[0])
			if abs(lastBest - self.best) < stuckTolerance: no_change += 1
			else: no_change = 0; lastBest = self.best
			#--- evaporate pheromone trail on the pathes
			self._evaporation()
			#--- intensify pheromone trail on the best path
			self._intensify(best_path[0])
			#--- update probabilities matrix
			self._update_probabilities()

			patternTxt = "\rIteration:%04d >> Best Score:%6.4f " + \
						">> OverallScore:%10.8f >> Time:%4.2fs"
			if verbose: sys.stdout.write(patternTxt % (i, 
				best_score[0], self.best, time.time() - start_iter))

			if no_change == maxStuck:
				patternTxt = "\nStopping early due to {} iterations of the same score."
				print(patternTxt.format(maxStuck))
				self.stopped_early = True; break

			#--- draw current map
			T = self.MatrixPheromone / np.max(self.MatrixPheromone)
			arr = np.array([[np.round(T[ii,jj]+0.5,2),\
				'#%0*X4444' % (2,int(T[ii,jj] * 255))] \
				for ii,jj in self.graph.edges()],dtype='object')
			self.graphOptions['width'] = list(arr[:,0])
			self.graphOptions['edge_color'] = list(arr[:,1])
			netx.draw(self.graph,**self.graphOptions)
			plt.plot();plt.pause(0.001);plt.cla()

		self.fit_time = time.time() - lastTime
		self.fitted = True

		if mode == 'min': idx = np.argmin(self.best_series)
		else: idx = np.argmax(self.best_series)
		self.best = self.best_series[idx]
		patternTxt = "\nACO fitted.  Runtime: {0:6.2f} seconds.  Best score: {1:10.6f}"
		if verbose: print(patternTxt.format(self.fit_time, self.best))

		#--- draw final map
		plt.ioff();plt.close()
		Process(target=self.drawGraph).start()
		Process(target=self.plot).start()

		return self.best, self.best_path

	def plot(self):
		"""
		Plots the score over time after the model has been fitted.
		:return: None if the model isn't fitted yet
		"""
		if not self.fitted:
			print("Ant Colony Optimizer not fitted!  There exists nothing to plot.")
			return None
		else:
			fig, ax = plt.subplots(figsize=(20, 15))
			ax.plot(self.best_series, label="Best Run")
			ax.set_xlabel("Iteration")
			ax.set_ylabel("Performance")
			ax.text(0.8, 0.6, 'Ants: %6d\nEvap Rate: %6.4f\nIntensify: \
				%6.4f\nAlpha: %6.4f\nBeta: %6.4f\nBeta Evap: %6.4f\nChoose Best: \
				%6.4f\n\nFit Time: %6.4fs%s' % (self.antsCount, \
				self.evapRate, self.intensRate, \
				self.heuristic_alpha, self.heuristic_beta, \
				self.evapRateBetha, self.choose_best, \
				self.fit_time, ["\nStopped Early!" \
				if self.stopped_early else ""][0]),
					bbox={'facecolor': 'gray', 'alpha': 0.8, \
						'pad': 10}, transform=ax.transAxes)
			ax.legend()
			plt.title("Ant Colony Optimization Results (best: {})"\
					.format(np.round(self.best, 2)))
			plt.show()

	def createGraph(self):
		if self.MatrixMap is None or self.points is None: return

		y = self.MatrixMap * np.triu(np.ones(self.MatrixMap.shape))
		idx = trans(np.where(y > 0))
		#--- list of vertices
		verts = list((v,{"color":"blue"}) for v in range(self.MatrixMap.shape[0]))
		#--- list of edges
		edges = list((i,j,{'color':'#FF0044', 'weight': '%3.2f' % self.MatrixMap[i,j]}) for i,j in idx)
		#--- geometerical position of vertices
		pos = dict((k,tuple(self.points[k,:])) for k in range(len(self.points)))
		self.graphOptions = {'pos':pos,'node_color': '#8888CC','font_size':10,\
			'node_size': 300,'width': 1,'edge_color':'#CC8888','with_labels':True}
		self.graph = netx.Graph()
		self.graph.add_nodes_from(verts)
		self.graph.add_edges_from(edges)

	def drawGraph(self):
		plt.figure('Urban Stations Map')
		netx.draw(self.graph,**self.graphOptions)
		edgeLbls = netx.get_edge_attributes(self.graph,'weight')
		netx.draw_networkx_edge_labels(self.graph,\
			self.graphOptions['pos'],edge_labels=edgeLbls,font_size=8)
		plt.plot();plt.show()
