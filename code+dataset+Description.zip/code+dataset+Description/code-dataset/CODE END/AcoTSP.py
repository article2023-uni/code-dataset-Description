import os, re, sys, time, msvcrt, argparse, warnings, \
	networkx, numpy as np, matplotlib.pyplot as plt, \
	win32clipboard as clipboard
from sklearn.preprocessing import normalize
from numpy import transpose as trans
from multiprocessing import Process
from scipy.spatial import distance


def ReadPath(fPath):
	try:
		f = open(fPath, 'r')#--- open file as text stream
		lines = f.readlines()	#--- read all lines
		f.close()			#--- close file handle
	except Exception as ex:
		print(ex)
		return None

	regex = '^\s*[\[\(\{]?[,\s]*([-+]?\d+\.?\d*)+' + \
		'([\s*,]+([-+]?\d+\.?\d*)+)*[,\s]*[\]\)\}]?\s*$'
	for line in lines:
		if re.match(regex, line):
			nums = re.findall(r'[-+]?\d+\.?\d*',line)
			x0 = np.abs(list(int(float(t)) for t in nums))
			return x0
	return None

def RandGraph(nx=6,ny=5,density=0.3,\
	full=False,show=False,outPath=None):
	#--- random data points
	#p = np.random.rand(nx*ny,2) * 10
	#--- random data points on grid template
	a,b = np.meshgrid(np.arange(nx),np.arange(ny))
	c,d = -1 + 2*np.random.rand(2,ny,nx)
	p = np.append((5*a+c).reshape(nx*ny,1),(5*b+d).reshape(nx*ny,1),axis=1)
	#--- distance matrix
	x = distance.cdist(p,p)

	if not full:
		#--- remove so-far distanced links
		idx = np.argsort(x,axis=1)
		I = np.transpose([np.arange(len(p))])
		J = idx[:,int(density*len(p)):]
		x[I,J] = x[J,I] = 0
	
		#--- remove edges that are very close to another nodes
		R = np.min(x[x>0]) / 2
		idx = np.transpose(np.where(np.triu(x) > 0))
		#--- get start/end node of edges
		xi = np.repeat(trans([p[idx[:,0],0]]),p.shape[0],axis=1)
		yi = np.repeat(trans([p[idx[:,0],1]]),p.shape[0],axis=1)
		xj = np.repeat(trans([p[idx[:,1],0]]),p.shape[0],axis=1)
		yj = np.repeat(trans([p[idx[:,1],1]]),p.shape[0],axis=1)
		#--- line segment paramerts : ax + by + c = 0
		a = (yj-yi); b = (xj-xi); c = yi*b - xi*a
		#--- nodes coordinates
		u = np.repeat([p[:,0]],a.shape[0],axis=0)
		v = np.repeat([p[:,1]],b.shape[0],axis=0)
		#--- calc distance of each node to edges
		d = np.abs(a*u-b*v+c) / np.sqrt(a**2 + b**2)
		#--- calc length of projection vectors
		h1 = np.sqrt((xi-u)**2 + (yi-v)**2 - d**2)
		h2 = np.sqrt((xj-u)**2 + (yj-v)**2 - d**2)
		#--- calc length of edge : both projection vectors must be less than this
		hh = np.sqrt((xi-xj)**2 + (yi-yj)**2)
		#--- indices of start node of edges
		I = np.repeat(trans([idx[:,0]]),p.shape[0],axis=1)
		#--- indices of end node of edges
		J = np.repeat(trans([idx[:,1]]),p.shape[0],axis=1)
		#--- indices of nodes
		K = np.repeat([np.arange(p.shape[0])],idx.shape[0],axis=0)
		#--- check all pairs of edges/nodes for if : start and end 
		#---  node of edge isn't equal to tobe check node and distance 
		#---  is less than a threshold and also check projection length
		jdx = (I != K) & (J != K) & (d <= R) & (h1 < hh) & (h2 < hh)
		#--- purify edge list
		idx = idx[np.sum(jdx,axis=1) > 0, :]
		#--- update distance matrix
		x[idx[:,0],idx[:,1]] = x[idx[:,1],idx[:,0]] = 0

	if show: Process(target=DrawGraph,args=(x,p)).start()

	if outPath is None:
		input_key = input('Save this map? Yes(y) / No(n): ')
		while input_key not in '[yYnN]':
			input_key = input('Save this map? Yes(y) / No(n): ')
		if input_key in 'yY': outPath = input('Enter file path : ')
	if outPath is not None:
		fmtE = 'edge-%03d\t%2d\t%2d\n'
		fmtV = 'vertice-%02d\t%6.4f\t%6.4f\n'
		#--- get non-zero elements of the distance matrix
		q = np.transpose(np.where(np.triu(x) > 0))
		#--- convert vertices and edges data to text lines
		txtList = list(fmtV % (k+1,p[k,0],p[k,1]) for k in range(len(p))) + \
			list(fmtE % (k+1,q[k,0],q[k,1]) for k in range(len(q)))
		#np.savetxt("Map.csv", distMap, fmt='%3.2f', delimiter=",")
		try:
			#--- open file as text stream
			f = open(outPath, 'w')
			#--- write all vertice lines
			d = f.writelines(txtList)
			#--- close file handle
			f.close()
			print('Output file was saved successfully!')
		except Exception as ex:
			print(ex)

	return x,p

def ReadDataset(fPath,density=0.3,full=False,show=False):
	try:
		f = open(fPath, 'r')#--- open file as text stream
		D = f.readlines()	#--- read all lines
		f.close()			#--- close file handle
	except Exception as ex:
		print(ex)
		return None, None
	
	#--- find lines start with prefix "vertice-"
	idx = list(s.startswith('vertice-') for s in D)
	#--- find lines start with prifix "edge-"
	jdx = list(s.startswith('edge-') for s in D)
	#--- separate numerical data lines by space delimiter
	x = np.array(list(np.array(s[8:].split()) for s in D),dtype='object')[idx]
	#--- convert separated strings to float values
	p = np.float32(list(t for t in x))[:,1:]
	#--- distance matrix
	M = distance.cdist(p,p)
	x = M.copy()
	g = np.zeros(x.shape,'bool')
	if np.sum(jdx) == 0 or full == False:
		#--- remove so-far distanced links
		k = int(density*x.shape[1])
		idx = np.argsort(x,axis=1)[:,k:]
		#--- remove randomly some pathes
		g[np.transpose([np.arange(len(p))]),idx] = True
	else:
		#--- separate numerical data lines by space delimiter
		V = np.array(list(np.array(s[4:].split()) for s in D),dtype='object')[jdx]
		#--- convert separated strings to float values
		jdx = np.int32(list(t for t in V))[:,1:]
		g[jdx[:,0],jdx[:,1]] = True
	g |= g.transpose()
	x[~g] = 0
	
	if show:
		#plt.scatter(x[:,0],x[:,1]); plt.show();plt.pause(0)
		np.set_printoptions(precision=2,threshold=3)
		y = x * np.triu(np.ones(x.shape))
		idx = np.transpose(np.where(y > 0))
		#--- list of vertices
		verts = list((v,{"color":"blue"}) for v in range(x.shape[0]))
		#--- list of edges
		edges = list((e[0],e[1],{'weight': '%3.2f'%x[e[0],e[1]]}) for e in idx)
		#--- geometerical position of vertices
		pos = dict((k,tuple(p[k,:])) for k in range(len(p)))
		options = {'pos':pos,'node_color': 'gray',\
			'node_size': 500,'width': 1,'with_labels':True}
		G = netx.Graph()
		G.add_nodes_from(verts)
		G.add_edges_from(edges)
		lbl = netx.get_edge_attributes(G,'weight')
		plt.figure('map')
		plt.subplot(111)
		netx.draw(G,**options)
		netx.draw_networkx_edge_labels(G,pos,edge_labels=lbl,font_size=8)
		plt.show()
	M[~g] = 0
	return M,p

def triples_angle(p,k=0):
	# destNode = p[k] ; 0 ≤ k ≤ m-1
	#---P = Set of points {p0,p1,...,p[m-1]}
	#--- all p[i]s are n-dimensional point
	m,n = p.shape
	#---Set of vectors {p[k]-p0, p[k]-p1, ..., p[k]-p[n-1]}
	q = p[k%m,:] - p
	#---X = norm2 matrix; length of all vectors of Q
	x = np.repeat(trans(q)**2,m,axis=0)
	x = x.reshape((n,m,m))
	x = np.sum(x,axis=0)
	# Y = Q * Q' ; dot-product of all vectors of Q
	y = np.matmul(q,trans(q))
	s = np.sqrt(x*trans(x))
	return y / (s+1e-18)

def CreateGraph(MatrixMap,points,edges=None):
	if MatrixMap is None or points is None: return None

	if edges is None:
		y = MatrixMap * np.triu(np.ones(MatrixMap.shape))
		idx = trans(np.where(y > 0))
	else:
		idx = edges
	#--- list of vertices
	verts = list((v,{"color":"blue"}) for v in range(MatrixMap.shape[0]))
	#--- list of edges
	edges = list((i,j,{'color':'#FF0044', 'weight': '%3.2f' % MatrixMap[i,j]}) for i,j in idx)
	#--- geometerical position of vertices
	pos = dict((k,tuple(points[k,:])) for k in range(len(points)))
	graphOptions = {'pos':pos,'node_color': '#AAAADD','font_size':10,\
		'node_size': 300,'width': 1,'edge_color':'#CCCCCC','with_labels':True}
	graph = networkx.Graph()
	graph.add_nodes_from(verts)
	graph.add_edges_from(edges)
	
	return graph,graphOptions

def DrawGraph(graph, graphOptions, title=None):
	if title is None: title = 'Urban Stations Map'
	plt.figure(title)
	networkx.draw(graph,**graphOptions)
	edgeLbls = networkx.get_edge_attributes(graph,'weight')
	networkx.draw_networkx_edge_labels(graph,graphOptions['pos'],\
								edge_labels=edgeLbls,font_size=8)
	plt.plot();plt.show()

def HalfSide(seg,p):
	#-- check that point 'p' is on which side of 'seg'
	u = seg[1]-seg[0]
	v = p-seg[0]
	return u[0]*v[1]-u[1]*v[0]

def HalfSideV(seg,P):
	#-- check that points 'P' are on which side of 'seg'
	u = seg[1]-seg[0]
	v = p-seg[0]
	return u[0]*v[1]-u[1]*v[0]

def SegmentIntersect(segA,segB):
	#-- https://math.stackexchange.com/questions/149622/finding-out-whether-two-line-segments-intersect-each-other
	pA = segA[0]; qA = segA[1]
	pB = segB[0]; qB = segB[1]
	H1 = HalfSide(segA,segB[0])
	H2 = HalfSide(segA,segB[1])
	H3 = HalfSide(segB,segA[0])
	H4 = HalfSide(segB,segA[1])
	return H1 * H2 <= 0 and H3 * H4 <= 0

def AllHalfsides(P):
	for i in range(P.shape[0]-1):
		for j in range(i+1,P.shape[0]):
			HalfSide()

def TryTours(P, nAnts, nNodes, startNode):
	fdx = np.arange(nAnts)
	I = np.ones(nNodes,'int')
	U = np.repeat([np.arange(nNodes)],nAnts,axis=0)
	t = U[:,0].copy(); U[:,0] = U[:,startNode].copy(); U[:,startNode] = t
	for j in range(1,nNodes-1):
		#idx = U[:,np.repeat(j-1,nNodes-j,axis=0)]
		#-- index of current node
		idx = U[:,(j-1)*I[j:]]
		#-- index of remind nodes
		jdx = U[:,j:]
		#-- probability map of paths between current 
		#--  node and remin nodes
		#-- cumulative probability map: needed to random choose
		Q = np.cumsum(normalize(P[idx,jdx]+1e-18,'l1'),axis=1)
		#-- create random numbers for each Ant
		rndArr = np.random.rand(Q.shape[0],1)
		#-- random selection based on probabilities
		#-- sum up number of probabilities bigger than rand-value
		kdx = np.sum(rndArr > Q, axis=1)
		#-- index to nNodes-j-1 to be selecting reminded nodes
		kdx = np.arange(j,nNodes)[kdx]
		#-- swap columns
		t = U[:,j].copy(); U[:,j] = U[fdx,kdx].copy(); U[fdx,kdx] = t
	return U

def TryTours2(P, nAnts, nNodes, startNode):
	fdx = np.arange(nAnts)
	I = np.ones(nNodes,'int')
	idx = np.int32(np.random.rand(nAnts)*nNodes)
	U = np.repeat([np.arange(nNodes)],nAnts,axis=0)
	t = U[:,0].copy(); U[:,0] = U[fdx,idx].copy(); U[fdx,idx] = t
	for j in range(1,nNodes-1):
		#idx = U[:,np.repeat(j-1,nNodes-j,axis=0)]
		#-- index of current node
		idx = U[:,(j-1)*I[j:]]
		#-- index of remind nodes
		jdx = U[:,j:]
		#-- probability map of paths between 
		#--		current node and remin nodes
		#-- cumulative probability map: needed to random choose
		Q = np.cumsum(normalize(P[idx,jdx] + 1e-18,'l1'),axis=1)
		#-- create random numbers for each Ant
		rndArr = np.random.rand(Q.shape[0],1)
		#-- random selection based on probabilities
		#-- sum up number of probabilities bigger than rand-value
		kdx = np.sum(rndArr > Q, axis=1)
		kdx = np.arange(j,nNodes)[kdx]
		t = U[:,j].copy(); U[:,j] = U[fdx,kdx].copy(); U[fdx,kdx] = t
	return U

def TryToursV(P, Angels, nAnts, startNode, destNode):
	nNodes = P.shape[0]
	fdx = np.arange(nAnts)
	I = np.ones(nNodes-1,'int')
	idx = np.int32(np.random.rand(nAnts)*(nNodes-1))
	U = np.repeat([list(range(destNode))+\
		list(range(destNode+1,nNodes))],nAnts,axis=0)
	t = U[:,0].copy(); U[:,0] = U[fdx,idx].copy(); U[fdx,idx] = t
	for j in range(1,nNodes-2):
		#-- index of current node
		idx = U[:,(j-1)*I[j:]]
		#-- index of remind nodes
		jdx = U[:,j:]
		#-- probability map of paths between 
		#--		current node and remin nodes
		Q = P[idx,jdx]*Angels[idx,jdx] + 1e-18
		#-- cumulative probability map: needed to random choose
		Q = np.cumsum(normalize(Q,'l1'),axis=1)
		#-- create random numbers for each Ant
		rndArr = np.random.rand(Q.shape[0],1)
		#-- random selection based on probabilities
		#-- sum up number of probabilities bigger than rand-value
		kdx = np.sum(rndArr > Q, axis=1)
		kdx = np.arange(j,nNodes)[kdx]
		t = U[:,j].copy(); U[:,j] = U[fdx,kdx].copy(); U[fdx,kdx] = t
	return np.append(U,np.zeros((nAnts,1),'int')+destNode,axis=1)

def AcoSearch(Map, points, x0=None, start=0, numAnts=20,\
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.2, evapRate=0.1, \
		evapRate2=0.5, stuckTolerance=0.05, maxStuck=-1,verbos=True,show=True):
	'''ACO algorithm : finding optimum tour by min/max score'''

	nNodes = Map.shape[0]; start %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf; cnt = 0
	lastTime = time.time();lastBest = np.inf
	maxStuck = maxStuck % iters if maxStuck < iters else iters
	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes)
	MatrixE = Map.copy();
	MatrixE[MatrixE != 0] **= -1

	#--- apply initial solution
	bInit = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < nNodes) and np.sum(Map[x0[:-1],x0[1:]] == 0) == 0 and \
		len(x0) == len(np.unique(x0))
	if bInit:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestScore = np.sum(Map[i,j]) + Map[x0[-1],x0[0]]
		bestPath = x0
		if verbos: print('Initial path score : %6.4f' % bestScore)
		sys.stdout.write('[InitPath: %6.4f]' % bestScore)
	else:
		if verbos: print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	for i in range(iters):
		#--- try some random paths
		U = TryTours2(MatrixP, numAnts, nNodes, start)
		
		scores = np.sum(Map[U[:,:-1],U[:,1:]],axis=1) + \
				Map[U[:,-1],U[:,0]]
		bestIdx = np.argmin(scores)
		bestScores.append(scores[bestIdx])
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			bestPath = U[bestIdx,:]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: cnt += 1
		else: cnt = 0; lastBest = bestScore
		if cnt >= maxStuck:
			#MatrixE = Map.copy();cnt = 0
			#MatrixE[MatrixE != 0] **= -1
			#MatrixT = 1 - np.eye(nNodes)
			#print('\n--- No more improvement; Reset heuristic params')
			if verbos: 
				print('\n--- No more improvement in ' + \
					'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		snrm = normalize(scores.reshape(1,-1),'l1')[0]
		MatrixT *= (1 - evapRate)
		tt = (1 - evapRate*(1 + snrm)) / (1 - evapRate)
		for k in range(U.shape[0]):
			MatrixT[U[k,:-1],U[k,1:]] *= tt[k]
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the current best path
		ii = U[bestIdx,:][:-1]
		jj = U[bestIdx,:][1:]
		MatrixT[ii, jj] += intensRate
		MatrixT[jj, ii] += intensRate
		#--- also intensify pheromones on the overal best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += intensRate
		MatrixT[jj,ii] += intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT**alpha) * (MatrixE**betha)
		
		if verbos:
			pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
			sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))
		
		#-- cancel if <Esc> pressed
		if msvcrt.kbhit() and msvcrt.getch() == b'\x1b': break

	elapsed = time.time() - lastTime
	if verbos:
		print('\n---------- Best Score : %6.4f ----------' % bestScore)
		sys.stdout.write('Optimal Path : ');print(bestPath)
		print('---------- Elapsed Time : %4.2fs ----------\n' % elapsed)
	
	if show:
		graph,graphOptions = CreateGraph(Map,points,np.transpose([bestPath[:-1],bestPath[1:]]))
		fig = plt.figure('Urban Stations Map')
		Process(target=DrawGraph, args=(graph,graphOptions,)).start()
	
	return elapsed, bestScore, bestPath

def AcoPsoSearch(Map, points, x0=None, start=0, numAnts=20,iters=1000, \
		alpha=0.8, betha=0.01, intensRate=0.1, evapRate=0.8, evapRate2=0.1, \
		c1=0.8, c2=0.1, stuckTolerance=0.05, maxStuck=-1,verbos=True,show=True):
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf
	lastBest = np.inf; maxStuck %= iters
	lastTime = time.time(); stuckCount = 0
	nNodes = Map.shape[0]; start %= nNodes

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes)
	MatrixE = Map.copy();cnt = 0
	MatrixE[MatrixE != 0] **= -1
	#--- personal best experience of ants
	pBestPath = np.repeat([np.arange(nNodes)],numAnts,axis=0)
	pBestScore = np.inf + np.zeros((1,numAnts))[0]
	#--- check initial solution validity
	checkX0 = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		np.sum(Map[x0[:-1],x0[1:]] == 0) == 0 and len(x0) == len(np.unique(x0))
	if checkX0:
		#--- apply initial solution
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		if verbos: print('Initial path score : %6.4f' % bestScore)
	else:
		if verbos: print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	#MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	if show:
		graph,graphOptions = CreateGraph(Map,points)
		fig = plt.figure('Urban Stations Map');plt.ion()
	
	for i in range(iters):
		#--- try some random paths
		try:U = TryTours2(MatrixP, numAnts, nNodes, start)
		except Exception as ex:
			if verbos: sys.stdout.write('\n[ERROR : %s]' % ex); break
		
		scores = np.sum(Map[U[:,:-1],U[:,1:]],axis=1)
		#--- update Personal Best
		jdx = scores < pBestScore
		pBestScore[jdx] = scores[jdx]
		pBestPath[jdx,:] = U[jdx,:]
		
		#--- find best path of this iteration (minimum score)
		bestIdx = np.argmin(scores)
		#--- register the best of this iteration
		bestScores.append(scores[bestIdx])
		#--- update global best path
		if scores[bestIdx] < bestScore:
			bestScore = scores[bestIdx]
			bestPath = U[bestIdx,:]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: stuckCount += 1
		else: stuckCount = 0; lastBest = bestScore
		if stuckCount >= maxStuck:
			if verbos: print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		snrm = normalize(scores.reshape(1,-1),'l1')[0]
		MatrixT *= (1 - evapRate)
		MatrixT[U[:,:-1],U[:,1:]] /= (1 - evapRate)
		for k in range(U.shape[0]):
			MatrixT[U[k,:-1],U[k,1:]] *= (1 - evapRate*(1+snrm[k]))
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the personal best paths
		kdx = ~np.isinf(pBestScore)
		pbs = pBestPath[kdx,:]
		for k in range(len(pbs)):
			ii = pbs[k,:-1]; jj = pbs[k,1:]
			MatrixT[ii, jj] += c2 * intensRate * (1+snrm[k])
			MatrixT[jj, ii] += c2 * intensRate * (1+snrm[k])
		#--- also intensify pheromones on the global best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += c1 * intensRate
		MatrixT[jj,ii] += c1 * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		ii = bestPath[:-1]; jj = bestPath[1:]
		x1 = np.sum(np.sum(np.triu(MatrixP)))
		x2 = np.sum(np.sum(MatrixP[ii,jj]))
		
		if verbos:
			pattern = '\r[Iteration: %4d >>> CurrBest : %8.4f][GlobalBest : %8.2f][%6.2f-%6.2f]'
			sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore,x1,x2))
		
		#-- cancel if <Esc> pressed
		if msvcrt.kbhit() and msvcrt.getch() == b'\x1b': break

	elapsed = time.time() - lastTime
	if verbos:
		print('\n---------- Best Score : %6.4f ----------' % bestScore)
		sys.stdout.write('Optimal Path : ');print(bestPath)
		print('---------- Elapsed Time : %4.2fs ----------\n' % elapsed)
	
	if show:
		#--- draw final map
		graph,graphOptions = CreateGraph(Map,points,np.transpose([bestPath[:-1],bestPath[1:]]))
		fig = plt.figure('Urban Stations Map')
		Process(target=DrawGraph, args=(graph,graphOptions,)).start()
	return elapsed, bestScore, bestPath

def AcoPsoSearchV(Map, points, x0=None, start=0, dest=-1, \
		numAnts=20, iters=1000, alpha=0.8, betha=0.01, \
		gamma=0.75, intensRate=0.1, evapRate=0.8, \
		evapRate2=0.1, c1=0.8, c2=0.2, stuckTolerance=0.05, \
		maxStuck=-1,verbos=True, show=True):
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf
	lastBest = np.inf; maxStuck %= iters
	lastTime = time.time(); stuckCount = 0

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes)
	MatrixE = Map.copy();
	MatrixE[MatrixE != 0] **= -1
	#--- personal best experience of ants
	pBestPath = np.repeat([np.arange(nNodes)],numAnts,axis=0)
	pBestScore = np.inf + np.zeros((1,numAnts))[0]
	#--- apply initial solution
	validX0 = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and \
		np.sum(Map[x0[:-1],x0[1:]] == 0) == 0 \
		and len(x0) == len(np.unique(x0))
	if validX0:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		if verbos: print('Initial path score : %6.4f' % bestScore)
	else:
		if verbos: print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
	#--- calculate angels matrix
	#--- angles between <p[destNode]-p[i]> and <p[destNode]-p[j]>
	MatrixA = triples_angle(points,dest)
	MatrixA[np.isinf(MatrixA) | np.isnan(MatrixA)] = 0
	MatrixA = (1 + MatrixA) ** gamma
	
	for i in range(iters):
		#--- try some random paths
		U = TryToursV(Map, MatrixA, numAnts, start, dest)
		
		scores = np.sum(Map[U[:,:-1],U[:,1:]],axis=1)
		#--- update Personal Best
		jdx = scores < pBestScore
		pBestScore[jdx] = scores[jdx]
		pBestPath[jdx,:] = U[jdx,:]
		
		#--- find best path of this iteration (ascending order)
		bestIdx = np.argmin(scores)
		#--- register the best of this iteration
		bestScores.append(scores[bestIdx])
		#--- update global best path
		if scores[bestIdx] < bestScore:
			bestScore = scores[bestIdx]
			bestPath = U[bestIdx,:]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: stuckCount += 1
		else: stuckCount = 0; lastBest = bestScore
		if stuckCount >= maxStuck:
			if verbos: print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the personal best paths
		kdx = ~np.isinf(pBestScore)
		pbs = pBestPath[kdx,:]
		for pb in pbs:
			ii = pb[:-1]; jj = pb[1:]
			MatrixT[ii, jj] += c2 * intensRate
			MatrixT[jj, ii] += c2 * intensRate
		#--- also intensify pheromones on the global best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += c1 * intensRate
		MatrixT[jj,ii] += c1 * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		
		if verbos:
			pattern = '\r[Iteration: %4d >>> CurrBest : %6.4f][GlobalBest : %6.2f]'
			sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))
		
		#-- cancel if <Esc> pressed
		if msvcrt.kbhit() and msvcrt.getch() == b'\x1b': break

	elapsed = time.time() - lastTime
	if verbos:
		print('\n---------- Best Score : %6.4f ----------' % bestScore)
		sys.stdout.write('Optimal Path : ');print(bestPath)
		print('---------- Elapsed Time : %4.2fs ----------\n' % elapsed)
	
	if show:
		#--- draw final map
		graph,graphOptions = CreateGraph(Map,points,np.transpose([bestPath[:-1],bestPath[1:]]))
		fig = plt.figure('Urban Stations Map')
		Process(target=DrawGraph, args=(graph,graphOptions,)).start()
	return elapsed, bestScore, bestPath


if __name__ == '__main__':
	np.set_printoptions(precision=3)
	bVectorized = False; x0 = None
	parser = argparse.ArgumentParser(description="ACO-PSO Civil Path Planning")
	parser.add_argument("--db", default='sample25.tsp', help="Database filename")
	parser.add_argument("--x0", type=str, default=None, help="Initial solution")
	parser.add_argument("--ants", type=int, default=20, help="Ants count")
	parser.add_argument("--iters", type=int, default=100, help="Iterations")
	parser.add_argument("--start", type=int, default=0, help="Start point")
	parser.add_argument("--dest", type=int, default=-1, help="Destination point")
	parser.add_argument("--c1", type=float, default=0.95, help="PSO param C1")
	parser.add_argument("--c2", type=float, default=0.05, help="PSO param C2")
	parser.add_argument("--aco", nargs=6, default=(0.8,0.01,0.75,0.2,0.1,0.5), type=float, help="PSO param C2")
	parser.add_argument("--stuck", type=int, default=20, help="Maximum count of no-improvement")
	parser.add_argument("--out", type=str, default=None, help="Output file name to save result path")
	parser.add_argument("-vect", action="store_true", help="if TRUE, perform vectorized ACO")
	#--- intialize parameters based on user input

	args = parser.parse_args()
	if args.x0 is not None:
		if args.x0.lower() == 'clipboard':
			clipboard.OpenClipboard()
			args.x0 = clipboard.GetClipboardData()
			clipboard.CloseClipboard()
		regex = '^\s*[\[\(\{]?[,\s]*([-+]?\d+\.?\d*)+' + \
			'([\s*,]+([-+]?\d+\.?\d*)+)*[,\s]*[\]\)\}]?\s*$'
		if re.match(regex, args.x0):
			nums = re.findall(r'[-+]?\d+\.?\d*',args.x0)
			x0 = np.abs(list(int(float(t)) for t in nums))
		elif os.path.exists(args.x0):
			x0 = ReadPath(args.x0)
		else:
			print('Invalid value for initial solution!\n' + \
				'Just a list of positive integers is allowed.')
	if args.db is not None: dbFName = args.db
	if args.iters is not None: itersCount = args.iters
	if args.start is not None: startNode = args.start
	if args.ants is not None: antsCount = args.ants
	if args.dest is not None: destNode = args.dest
	if args.stuck is not None: maxStuck = args.stuck
	if args.c1 is not None: c1 = args.c1
	if args.c2 is not None: c2 = args.c2
	if args.aco is not None: params = args.aco
	if args.vect: bVectorized = True

	distMap,pointsList = ReadDataset(fPath=dbFName,density=0.0,full=True)
	#distMap,pointsList = RandGraph(6,8,0.15,show=True,outPath='sample48.tsp')
	
	if distMap is None or len(distMap) == 0:
		print('---> ERROR : Could not read/create database file!')
		sys.exit(0)

	method = 2
	if method == 1:
		_,_,x0 = AcoSearch(distMap,pointsList,x0,startNode,\
					antsCount,itersCount,alpha=params[0],betha=params[1],\
					intensRate=params[3],evapRate=params[4],evapRate2=\
					params[5],maxStuck=maxStuck)
	elif method == 2:
		_,_,x0 = AcoPsoSearch(distMap,pointsList,x0,startNode,\
				antsCount,itersCount,alpha=params[0],betha=params[1],\
				intensRate=params[3],evapRate=params[4],evapRate2=\
				params[5],c1=c1,c2=c2,maxStuck=maxStuck)
	elif method == 3:
		_,_,x0 = AcoPsoSearchV(distMap,pointsList,x0,startNode,\
					destNode,antsCount,itersCount,alpha=params[0],\
					betha=params[1],gamma=params[2],intensRate=params[3],\
					evapRate=params[4],evapRate2=params[5],maxStuck=maxStuck)
	clipboard.OpenClipboard()
	clipboard.EmptyClipboard()
	clipboard.SetClipboardText(np.array_str(x0))
	clipboard.CloseClipboard()
	if method in [1,2,3]: sys.exit(0)

	resArr = np.zeros((100,2),'float')
	for k in range(resArr.shape[0]):
		if method == 4:
			resVal = AcoSearch(distMap,pointsList,x0,startNode,\
					antsCount,itersCount,maxStuck=maxStuck,\
					verbos=False,show=False)
		elif method == 5:
			resVal = AcoPsoSearch(distMap,pointsList,x0,startNode,\
				antsCount,itersCount,alpha=params[0],betha=params[1],\
				intensRate=params[2],evapRate=params[3],evapRate2=\
				params[4],c1=c1,c2=c2,maxStuck=maxStuck,verbos=False,show=False)
		if method == 6:
			resVal = AcoPsoSearchV(distMap,pointsList,x0,startNode,\
				destNode,antsCount,itersCount,c1=c1,c2=c2,\
				maxStuck=maxStuck,verbos=False,show=False)
		print('[Run %3d/%3d][Time : %6.2f][Score : %6.4f] Press <Esc> to cancel' % \
				(k,resArr.shape[0],resVal[0],resVal[1]))
		x0 = np.array(resVal[2])
		resArr[k,0] = resVal[0] # --- elapsed time
		resArr[k,1] = resVal[1] # --- path score
		#-- wait user input; terminate if pressed <Esc>
		if msvcrt.kbhit() and msvcrt.getch() == b'\x1b': break

	sys.stdout.write('Optimal Path : ');print(x0)
	fresname = 'Berlin52[n-%d][ants-%d].csv' % (itersCount,antsCount)
	with open(fresname, 'ab') as fid:
		np.savetxt(fid,resArr,delimiter='\t',fmt='%6.4f')
		fid.close()
	with open(fresname, 'ab') as fid:
		#-- append the best tour on results csv file
		np.savetxt(fid,np.array(x0).reshape(1,len(x0)),delimiter='\t',fmt='%3d')
		fid.close()

	clipboard.OpenClipboard()
	clipboard.EmptyClipboard()
	clipboard.SetClipboardText(np.array_str(x0))
	clipboard.CloseClipboard()

	graph,graphOptions = CreateGraph(distMap,\
		pointsList,np.transpose([x0[:-1],x0[1:]]))
	fig = plt.figure('Urban Stations Map')
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()
