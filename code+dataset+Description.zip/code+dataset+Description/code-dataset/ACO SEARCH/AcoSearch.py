import sys, time, warnings, networkx, \
	numpy as np, matplotlib.pyplot as plt
from numpy import transpose as trans
from multiprocessing import Process
def sumrow(x): return np.sum(x,axis=0)
def sumcol(x): return np.sum(x,axis=1)
def cumsumrow(x): return np.cumsum(x,axis=0)
def cumsumcol(x): return np.cumsum(x,axis=1)

def CreateGraph(MatrixMap,points):
	if MatrixMap is None or points is None: return None

	y = MatrixMap * np.triu(np.ones(MatrixMap.shape))
	idx = trans(np.where(y > 0))
	#--- list of vertices
	verts = list((v,{"color":"blue"}) for v in range(MatrixMap.shape[0]))
	#--- list of edges
	edges = list((i,j,{'color':'#FF0044', 'weight': '%3.2f' % MatrixMap[i,j]}) for i,j in idx)
	#--- geometerical position of vertices
	pos = dict((k,tuple(points[k,:])) for k in range(len(points)))
	graphOptions = {'pos':pos,'node_color': '#AAAADD','font_size':10,\
		'node_size': 300,'width': 1,'edge_color':'#CCCCCC','with_labels':True}
	graph = networkx.Graph()
	graph.add_nodes_from(verts)
	graph.add_edges_from(edges)
	
	return graph,graphOptions

def DrawGraph(graph,graphOptions):
	plt.figure('Urban Stations Map')
	networkx.draw(graph,**graphOptions)
	edgeLbls = networkx.get_edge_attributes(graph,'weight')
	networkx.draw_networkx_edge_labels(graph,graphOptions['pos'],\
								edge_labels=edgeLbls,font_size=8)
	plt.plot();plt.show()

def TryPaths(P, nAnts, nNodes, startNode, destNode):
	I = np.ones((1,nNodes),'int')[0]
	U = np.repeat([np.arange(nNodes)],nAnts,axis=0)
	t = U[:,0].copy(); U[:,0] = U[:,startNode].copy(); U[:,startNode] = t
	for j in range(1,nNodes):
		idx = (U[:,j-1] != U[:,j]) & (U[:,j-1] != destNode)
		if sum(idx) == 0: U[:,j:] = U[:,(j-1)*I[j:]]; break
		udx = U[:,(j-1)*I[j:]]
		Q = P[udx,U[:,j:]]
		sumQ = np.sum(Q,axis=1) + 1e-9
		Q = np.cumsum(Q / trans([sumQ]),axis=1)
		rndArr = np.random.rand(Q.shape[0],1)
		rdx = np.sum(rndArr > Q, axis=1)
		idx &= (rdx < Q.shape[1])
		mdx = np.arange(j,nNodes)[rdx[idx]]
		t = U[idx,j].copy(); U[idx,j] = U[idx,mdx].copy(); U[idx,mdx] = t
		U[~idx,j:] = trans([U[~idx,j-1]])[:,1-I[j:]]
	return U

def TryPathsEx(Map, Congest, Tau, alpha, betha, nAnts, nNodes, startNode, destNode):
	
	I = np.ones((1,nNodes),'int')[0]
	U = np.repeat([np.arange(nNodes)],nAnts,axis=0)
	t = U[:,0].copy()
	U[:,0] = U[:,startNode].copy()
	U[:,startNode] = t
	for j in range(1,nNodes):
		idx = (U[:,j-1] != U[:,j]) & (U[:,j-1] != destNode)
		if sum(idx) == 0: U[:,j:] = U[:,(j-1)*I[j:]]; break
		udx = U[:,(j-1)*I[j:]]
		Etha = 1 / (Congest + Map)
		Etha[np.isinf(Etha) | np.isnan(Etha)] = 0
		P = (Tau ** alpha) * (Etha ** betha)
		Q = P[udx,U[:,j:]]
		sumQ = sumcol(Q) + 1e-9
		Q = cumsumcol(Q / trans([sumQ]))
		rndArr = np.random.rand(Q.shape[0],1)
		rdx = np.sum(rndArr > Q, axis=1)
		idx&= (rdx < Q.shape[1])
		mdx = np.arange(j,nNodes)[rdx[idx]]
		t = U[idx,j].copy(); U[idx,j] = U[idx,mdx].copy(); U[idx,mdx] = t
		U[~idx,j:] = trans([U[~idx,j-1]])[:,1-I[j:]]
		#--- some vehicles exited from current roads
		if j > 1: Congest[U[idx,j-2],U[idx,j-1]] -= 1
		#--- some vehicles entered the new roads
		Congest[U[idx,j-1],U[idx,j-0]] += 1
	return U

def TryPathsEy(Map, Angels, Congest, Tau, alpha, betha, nAnts, nNodes, startNode, destNode):
	
	I = np.ones((1,nNodes),'int')[0]
	U = np.repeat([np.arange(nNodes)],nAnts,axis=0)
	t = U[:,0].copy()
	U[:,0] = U[:,startNode].copy()
	U[:,startNode] = t
	for j in range(1,nNodes):
		idx = (U[:,j-1] != U[:,j]) & (U[:,j-1] != destNode)
		if sum(idx) == 0: U[:,j:] = U[:,(j-1)*I[j:]]; break
		udx = U[:,(j-1)*I[j:]]
		Etha = 1 / (Congest + Map)
		Etha[np.isinf(Etha) | np.isnan(Etha)] = 0
		P = (Tau ** alpha) * (Etha ** betha)
		Q = P[udx,U[:,j:]] ** Angels[udx,U[:,j:]]
		sumQ = sumcol(Q) + 1e-9
		Q = cumsumcol(Q / trans([sumQ]))
		rndArr = np.random.rand(Q.shape[0],1)
		rdx = np.sum(rndArr > Q, axis=1)
		idx&= (rdx < Q.shape[1])
		mdx = np.arange(j,nNodes)[rdx[idx]]
		t = U[idx,j].copy(); U[idx,j] = U[idx,mdx].copy(); U[idx,mdx] = t
		U[~idx,j:] = trans([U[~idx,j-1]])[:,1-I[j:]]
		#--- some vehicles exited from current roads
		if j > 1: Congest[U[idx,j-2],U[idx,j-1]] -= 1
		#--- some vehicles entered the new roads
		Congest[U[idx,j-1],U[idx,j-0]] += 1
	return U

def AcoSearchM(Map, points, x0=None, start=0, dest=-1, numAnts=20,\
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.5, \
		evapRate=0.5, evapRate2=0.0, stuckTolerance=0.05, maxStuck=-1):
	'''ACO algorithm : finding best path by min/max score'''
	
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf; cnt = 0
	lastTime = time.time();lastBest = np.inf; maxStuck %= iters

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes);MatrixE = 1 / Map
	#--- apply initial solution
	bInit = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		(x0[-1] == dest) and np.prod(Map[x0[:-1],x0[1:]] > 0) > 0
	if bInit:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		print('Initial path score : %6.4f' % bestScore)
	else:
		print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	graph,graphOptions = CreateGraph(Map,points)
	fig = plt.figure('Urban Stations Map');plt.ion()

	for i in range(iters):
		#--- try some random paths
		U = TryPaths(MatrixP, numAnts, nNodes, start, dest)
		#--- only paths end to the desired destination
		idx = U[:,-1] == dest; U = U[idx,:]
		#--- if no paths with desired destination, go back
		if U.shape[0] == 0: continue
		
		scores = np.sum(Map[U[:,:-1],U[:,1:]],axis=1)
		bestIdx = np.argmin(scores)
		bestScores.append(scores[bestIdx])
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			k = sum(U[bestIdx,:] != dest) + 1
			bestPath = U[bestIdx,:k]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: cnt += 1
		else: cnt = 0; lastBest = bestScore
		if cnt >= maxStuck:
			print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the current best path
		k = sum(U[bestIdx,:] != dest) + 1
		ii = U[bestIdx,:k][:-1]
		jj = U[bestIdx,:k][1:]
		MatrixT[ii, jj] += intensRate
		MatrixT[jj, ii] += intensRate
		#--- also intensify pheromones on the overal best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += weights[k] * intensRate
		MatrixT[jj,ii] += weights[k] * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		
		pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
		sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))

		#--- draw current map
		S = MatrixP / np.max(MatrixP)
		arr = np.array([[S[ii,jj]+0.25,'#%0*X4444' % (2,int(S[ii,jj] * 255))] \
			for ii,jj in graph.edges()],dtype='object')
		graphOptions['width'] = list(arr[:,0])
		graphOptions['edge_color'] = list(arr[:,1])
		networkx.draw(graph,**graphOptions)
		plt.plot();plt.pause(0.001);plt.cla()

	print('\n---------- Best Score : %6.4f ----------' % bestScore)
	sys.stdout.write('Optimal Path : ');print(bestPath)
	print('---------- Elapsed Time : %4.2fs ----------\n' % (time.time() - lastTime))
	
	#--- draw final map
	plt.ioff();plt.close()
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()

def AcoSearchS(Map, points, x0=None, start=0, dest=-1, numAnts=20,\
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.5, \
		evapRate=0.5, evapRate2=0.0, stuckTolerance=0.05, maxStuck=-1):
	'''ACO algorithm : finding best path by sorting scores'''
	
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf;
	cnt = 0; maxStuck %= iters
	lastTime = time.time();lastBest = np.inf

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes);MatrixE = 1 / Map
	#--- apply initial solution
	bInit = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		(x0[-1] == dest) and np.prod(Map[x0[:-1],x0[1:]] > 0) > 0
	if bInit:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		print('Initial path score : %6.4f' % bestScore)
	else:
		print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	graph,graphOptions = CreateGraph(Map,points)
	plt.figure('Urban Stations Map'); plt.ion()

	for i in range(iters):
		#--- try some random paths
		U = TryPaths(MatrixP, numAnts, nNodes, start, dest)
		#--- only paths end to the desired destination
		idx = U[:,-1] == dest; U = U[idx,:]
		#--- if no paths with desired destination, go back
		if U.shape[0] == 0: continue
		
		scores = np.sum(Map[U[:,:-1],U[:,1:]],axis=1)
		bestIdx = np.argsort(scores)
		bestScores.append(scores[bestIdx[0]])
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			k = sum(U[bestIdx[0],:] != dest) + 1
			bestPath = U[bestIdx[0],:k]

		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: cnt += 1
		else: cnt = 0; lastBest = bestScore
		if cnt >= maxStuck:
			print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- update 'MatrixT': intensify pheromone on the best paths
		U = U[bestIdx[:2],:]
		weights = 1 / (scores[bestIdx[:2]] + 1e-9)
		weights = np.array(weights) / np.max(weights)
		for k in range(U.shape[0]):
			kk = sum(U[k,:] != dest) + 1
			ii = U[k,:kk][:-1]; jj = U[k,:kk][1:]
			MatrixT[ii,jj] += weights[k] * intensRate
			MatrixT[jj,ii] += weights[k] * intensRate
		#--- also intensify pheromones on the overal best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += weights[k] * intensRate
		MatrixT[jj,ii] += weights[k] * intensRate
		#I = np.ones((1,nNodes),'int')[0]; MatrixT[I,I] = 0

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
		sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))

		#--- draw current map
		S = MatrixP / np.max(MatrixP)
		arr = np.array([[S[ii,jj]+0.25,'#%0*X4444' % (2,int(S[ii,jj] * 255))] \
			for ii,jj in graph.edges()],dtype='object')
		graphOptions['width'] = list(arr[:,0])
		graphOptions['edge_color'] = list(arr[:,1])
		networkx.draw(graph,**graphOptions)
		plt.plot();plt.pause(0.001);plt.cla()

	print('\n---------- Best Score : %6.4f ----------' % bestScore)
	sys.stdout.write('Optimal Path : ');print(bestPath)
	print('---------- Elapsed Time : %4.2fs ----------\n' % (time.time() - lastTime))

	#--- draw final map
	plt.ioff();plt.close()
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()

def AcoPsoSearch(Map, points, x0=None, start=0, dest=-1, numAnts=20,\
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.5, evapRate=0.5, \
		evapRate2=0.0, c1=0.8, c2=0.2, stuckTolerance=0.05, maxStuck=-1):
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf
	lastBest = np.inf; maxStuck %= iters
	lastTime = time.time(); stuckCount = 0

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes)
	MatrixE = 1 / Map
	#--- personal best experience of ants
	pBestPath = np.repeat([np.arange(nNodes)],numAnts,axis=0)
	pBestScore = np.inf + np.zeros((1,numAnts))[0]
	#--- apply initial solution
	checkX0 = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		(x0[-1] == dest) and np.prod(Map[x0[:-1],x0[1:]] > 0) > 0
	if checkX0:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		print('Initial path score : %6.4f' % bestScore)
	else:
		print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	graph,graphOptions = CreateGraph(Map,points)
	fig = plt.figure('Urban Stations Map');plt.ion()
	
	for i in range(iters):
		#--- try some random paths
		U = TryPaths(MatrixP, numAnts, nNodes, start, dest)
		#--- only paths end to the desired destination
		idx = np.arange(numAnts)[U[:,-1] == dest]
		#--- if no paths with desired destination, go back
		if len(idx) == 0: continue
		
		scores = np.sum(Map[U[idx,:-1],U[idx,1:]],axis=1)
		#--- update Personal Best
		jdx = scores < pBestScore[idx]
		pBestScore[idx[jdx]] = scores[jdx]
		pBestPath[idx[jdx],:] = U[idx[jdx],:]
		
		#--- filter allowed paths
		U = U[idx,:]
		#--- find best path of this iteration (minimum score)
		bestIdx = np.argmin(scores)
		#--- register the best of this iteration
		bestScores.append(scores[bestIdx])
		#--- update global best path
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			k = sum(U[bestIdx,:] != dest) + 1
			bestPath = U[bestIdx,:k]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: stuckCount += 1
		else: stuckCount = 0; lastBest = bestScore
		if stuckCount >= maxStuck:
			print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the personal best paths
		kdx = ~np.isinf(pBestScore)
		#ps = 1/pBestScore[kdx]
		#ps /= np.max(ps) / 2
		pb = pBestPath[kdx,:]
		K = np.sum(pb != dest, axis=1) + 1
		for j in range(len(K)):
			wgt = c2 * intensRate
			ii = pb[j,:K[j]][:-1]; jj = pb[j,:K[j]][1:]
			MatrixT[ii, jj] += wgt; MatrixT[jj, ii] += wgt
		#--- also intensify pheromones on the global best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += c1 * intensRate
		MatrixT[jj,ii] += c1 * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		
		pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
		sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))

		#--- draw current map
		S = MatrixP / np.max(MatrixP)
		arr = np.array([[S[ii,jj]+0.25,'#%0*X4444' % (2,int(S[ii,jj] * 255))] \
			for ii,jj in graph.edges()],dtype='object')
		graphOptions['width'] = list(arr[:,0])
		graphOptions['edge_color'] = list(arr[:,1])
		networkx.draw(graph,**graphOptions)
		plt.plot();plt.pause(0.0001);plt.cla()

	print('\n---------- Best Score : %6.4f ----------' % bestScore)
	sys.stdout.write('Optimal Path : ');print(bestPath)
	print('---------- Elapsed Time : %4.2fs ----------\n' % (time.time() - lastTime))
	
	#--- draw final map
	plt.ioff();plt.close()
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()

def AcoPsoSearchEx(Map, Congest, points, x0=None, start=0, dest=-1, numAnts=20, \
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.5, evapRate=0.5, \
		evapRate2=0.0, c1=0.8, c2=0.2, stuckTolerance=0.05, maxStuck=-1):
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf
	lastBest = np.inf; maxStuck %= iters
	lastTime = time.time(); stuckCount = 0

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes); MatrixE = 1 / (Congest + Map)
	#--- personal best experience of ants
	pBestPath = np.repeat([np.arange(nNodes)],numAnts,axis=0)
	pBestScore = np.inf + np.zeros((1,numAnts))[0]
	#--- apply initial solution
	checkX0 = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		(x0[-1] == dest) and np.prod(Map[x0[:-1],x0[1:]] > 0) > 0
	if checkX0:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		print('Initial path score : %6.4f' % bestScore)
	else:
		print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)

	graph,graphOptions = CreateGraph(Map,points)
	fig = plt.figure('Urban Stations Map');plt.ion()
	
	for i in range(iters):
		#--- try some random paths
		U = TryPathsEx(Map, Congest.copy(), MatrixT, \
			alpha, betha, numAnts, nNodes, start, dest)
		#--- only paths end to the desired destination
		idx = np.arange(numAnts)[U[:,-1] == dest]
		#--- if no paths with desired destination, go back
		if len(idx) == 0: continue
		
		scores = np.sum(Map[U[idx,:-1],U[idx,1:]],axis=1)
		#--- update Personal Best
		jdx = scores < pBestScore[idx]
		pBestScore[idx[jdx]] = scores[jdx]
		pBestPath[idx[jdx],:] = U[idx[jdx],:]
		
		#--- filter allowed paths
		U = U[idx,:]
		#--- find best path of this iteration (ascending order)
		bestIdx = np.argsort(scores)
		#--- register the best of this iteration
		bestScores.append(scores[bestIdx[0]])
		#--- update global best path
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			k = sum(U[bestIdx[0],:] != dest) + 1
			bestPath = U[bestIdx[0],:k]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: stuckCount += 1
		else: stuckCount = 0; lastBest = bestScore
		if stuckCount >= maxStuck:
			print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the personal best paths
		kdx = ~np.isinf(pBestScore)
		#ps = 1/pBestScore[kdx]
		#ps /= np.max(ps) / 2
		pb = pBestPath[kdx,:]
		K = np.sum(pb != dest, axis=1) + 1
		for j in range(len(K)):
			wgt = c2 * intensRate
			ii = pb[j,:K[j]][:-1]; jj = pb[j,:K[j]][1:]
			MatrixT[ii, jj] += wgt; MatrixT[jj, ii] += wgt
		#--- also intensify pheromones on the global best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += c1 * intensRate
		MatrixT[jj,ii] += c1 * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		
		pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
		sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))

		#--- draw current map
		S = MatrixP / np.max(MatrixP)
		arr = np.array([[S[ii,jj]+0.25,'#%0*X4444' % (2,int(S[ii,jj] * 255))] \
			for ii,jj in graph.edges()],dtype='object')
		graphOptions['width'] = list(arr[:,0])
		graphOptions['edge_color'] = list(arr[:,1])
		networkx.draw(graph,**graphOptions)
		plt.plot();plt.pause(0.001);plt.cla()

	print('\n---------- Best Score : %6.4f ----------' % bestScore)
	sys.stdout.write('Optimal Path : ');print(bestPath)
	sys.stdout.write('Other Optimal Paths: \n')
	for j in range(min(4,len(bestIdx))):
		k = sum(U[bestIdx[j],:] != dest) + 1
		print(U[bestIdx[j],:k])
		sys.stdout.write('>> Score = %6.4f\n' % scores[bestIdx[j]])
	
	print('---------- Elapsed Time : %4.2fs ----------\n' % (time.time() - lastTime))
	
	#--- draw final map
	plt.ioff();plt.close()
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()

def AcoPsoSearchEy(Map, Congest, points, x0=None, start=0, dest=-1, numAnts=20, \
		iters=1000, alpha=0.5, betha=0.1, intensRate=0.5, evapRate=0.5, \
		evapRate2=0.0, c1=0.8, c2=0.2, stuckTolerance=0.05, maxStuck=-1):
	nNodes = Map.shape[0]
	start %= nNodes; dest %= nNodes
	bestPaths = []; bestScores = []
	bestPath = None; bestScore = np.inf
	lastBest = np.inf; maxStuck %= iters
	lastTime = time.time(); stuckCount = 0

	#--- initialize pheromone matrix
	MatrixT = 1 - np.eye(nNodes); MatrixE = 1 / (Congest + Map)
	#--- personal best experience of ants
	pBestPath = np.repeat([np.arange(nNodes)],numAnts,axis=0)
	pBestScore = np.inf + np.zeros((1,numAnts))[0]
	#--- apply initial solution
	checkX0 = (x0 is not None) and (min(x0) >= 0) and \
		(max(x0) < Map.shape[0]) and (x0[0] == start) and \
		(x0[-1] == dest) and np.prod(Map[x0[:-1],x0[1:]] > 0) > 0
	if checkX0:
		i = x0[:-1]; j = x0[1:]
		MatrixT[i,j] += 8 * intensRate
		MatrixT[j,i] += 8 * intensRate
		bestPath = x0; bestScore = np.sum(Map[i,j])
		print('Initial path score : %6.4f' % bestScore)
	else:
		print('>>> Warning : Invalid initial path')

	#--- correct heuristic matrix
	MatrixE[np.isinf(MatrixE) | np.isnan(MatrixE)] = 0
	#--- calculate probabilities matrix
	MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
	#--- calculate angels matrix
	#--- angles between <p[destNode]-p[i]> and <p[destNode]-p[j]>
	pn = points[dest,:] - points
	a0,b0 = np.meshgrid(pn[:,0],pn[:,0])
	a1,b1 = np.meshgrid(pn[:,1],pn[:,1])
	cc = np.sqrt(a0**2+a1**2) * np.sqrt(b0**2+b1**2)
	MatrixA = np.matmul(pn,trans(pn)) / cc
	MatrixA[np.isinf(MatrixA) | np.isnan(MatrixA)] = 0
	MatrixA[~(np.isinf(MatrixA) | np.isnan(MatrixA))] += 1
	MatrixA = MatrixA**0.75

	graph,graphOptions = CreateGraph(Map,points)
	fig = plt.figure('Urban Stations Map');plt.ion()
	
	for i in range(iters):
		#--- try some random paths
		U = TryPathsEy(Map, MatrixA, Congest.copy(), MatrixT, \
			alpha, betha, numAnts, nNodes, start, dest)
		#--- only paths end to the desired destination
		idx = np.arange(numAnts)[U[:,-1] == dest]
		#--- if no paths with desired destination, go back
		if len(idx) == 0: continue
		
		scores = np.sum(Map[U[idx,:-1],U[idx,1:]],axis=1)
		#--- update Personal Best
		jdx = scores < pBestScore[idx]
		pBestScore[idx[jdx]] = scores[jdx]
		pBestPath[idx[jdx],:] = U[idx[jdx],:]
		
		#--- filter allowed paths
		U = U[idx,:]
		#--- find best path of this iteration (ascending order)
		bestIdx = np.argsort(scores)
		#--- register the best of this iteration
		bestScores.append(scores[bestIdx[0]])
		#--- update global best path
		if bestScores[-1] < bestScore:
			bestScore = bestScores[-1]
			k = sum(U[bestIdx[0],:] != dest) + 1
			bestPath = U[bestIdx[0],:k]
		
		#--- check if process is stucking!?
		absErr = abs(bestScore - lastBest)
		if absErr < stuckTolerance: stuckCount += 1
		else: stuckCount = 0; lastBest = bestScore
		if stuckCount >= maxStuck:
			print('\n--- No more improvement in ' + \
				'the last %d iterations!' % maxStuck)
			break

		#--- evaporate pheromone matrix
		MatrixT *= (1 - evapRate)
		betha *= (1 - evapRate2)

		#--- intensifiy pheromones on the personal best paths
		kdx = ~np.isinf(pBestScore)
		#ps = 1/pBestScore[kdx]
		#ps /= np.max(ps) / 2
		pb = pBestPath[kdx,:]
		K = np.sum(pb != dest, axis=1) + 1
		for j in range(len(K)):
			wgt = c2 * intensRate
			ii = pb[j,:K[j]][:-1]; jj = pb[j,:K[j]][1:]
			MatrixT[ii, jj] += wgt; MatrixT[jj, ii] += wgt
		#--- also intensify pheromones on the global best path
		ii = bestPath[:-1]; jj = bestPath[1:]
		MatrixT[ii,jj] += c1 * intensRate
		MatrixT[jj,ii] += c1 * intensRate

		#--- update probabilities matrix
		MatrixP = (MatrixT ** alpha) * (MatrixE ** betha)
		
		pattern = '\rIteration: %4d >>> Best Score : %6.4f >>> Global Best : %6.2f'
		sys.stdout.write(pattern % (i+1,bestScores[-1],bestScore))

		#--- draw current map
		S = MatrixP / np.max(MatrixP)
		arr = np.array([[S[ii,jj]+0.25,'#%0*X4444' % (2,int(S[ii,jj] * 255))] \
			for ii,jj in graph.edges()],dtype='object')
		graphOptions['width'] = list(arr[:,0])
		graphOptions['edge_color'] = list(arr[:,1])
		networkx.draw(graph,**graphOptions)
		plt.plot();plt.pause(0.001);plt.cla()

	print('\n---------- Best Score : %6.4f ----------' % bestScore)
	sys.stdout.write('Optimal Path : ');print(bestPath)
	sys.stdout.write('Other Optimal Paths: \n')
	for j in range(min(4,len(bestIdx))):
		k = sum(U[bestIdx[j],:] != dest) + 1
		print(U[bestIdx[j],:k])
		sys.stdout.write('>> Score = %6.4f\n' % scores[bestIdx[j]])
	
	print('---------- Elapsed Time : %4.2fs ----------\n' % (time.time() - lastTime))
	
	#--- draw final map
	plt.ioff();plt.close()
	Process(target=DrawGraph, args=(graph,graphOptions,)).start()
